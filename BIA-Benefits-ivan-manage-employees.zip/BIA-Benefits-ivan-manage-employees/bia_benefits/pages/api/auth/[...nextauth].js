import NextAuth from "next-auth";
import EmailProvider from "next-auth/providers/email";
import { MongoDBAdapter } from "@next-auth/mongodb-adapter";
import BiaEmp from "@/models/biaEmployeeSchema";
import BIZ from "@/models/bizSchema";
import BUS from "@/models/businessEmployeesSchema";
import CorporatePartners from "@/models/corporatePartnerSchema";
import clientPromise from "@/pages/lib/clientPromise";
import connectDB from "@/utils/connectDB";

export default async function auth(req, res) {
  return NextAuth(req, res, {
    session: {
      strategy: "jwt",
    },
    adapter: MongoDBAdapter(await clientPromise),
    providers: [
      EmailProvider({
        server: {
          host: process.env.EMAIL_SERVER_HOST,
          port: process.env.EMAIL_SERVER_PORT,
          auth: {
            user: process.env.EMAIL_SERVER_USER,
            pass: process.env.EMAIL_SERVER_PASSWORD,
          },
        },
        from: process.env.EMAIL_FROM,
        maxAge: 24 * 60 * 60,
      }),
    ],
    callbacks: {
      async signIn(user) {
        try {
          await connectDB();
          const biaEmployeeEmailList = (await BiaEmp.find({}, 'employee_email')).map(doc => doc.employee_email);
          const bizEmailList = (await BIZ.find({}, 'email')).map(doc => doc.email);
          const corporPartnersEmailList = (await CorporatePartners.find({}, 'email')).map(doc => doc.email);
          const businessEmpEmailList = (await BUS.find({}, 'email')).map(doc => doc.email);
            
          if (!biaEmployeeEmailList.includes(user.user.email) && !bizEmailList.includes(user.user.email) && !corporPartnersEmailList.includes(user.user.email) && !businessEmpEmailList.includes(user.user.email)) {
            throw new Error("This email is not registered!");
          }          
      
          return true;
        } catch (err) {
          return false;
        }
      },
    }
  });
}
