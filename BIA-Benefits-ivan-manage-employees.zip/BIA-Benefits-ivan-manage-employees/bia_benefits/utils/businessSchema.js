import { Schema, model, models } from "mongoose";

const BusinessSchema = new Schema(
  {
    business_name: { type: String, required: true },
    address: { type: String, required: true },
    phone_number: { type: String, required: true },
    email: {
      type: String,
      required: [true, "Email is required."],
      unique: [true, "Email already exists!"],
      match: [
        /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/,
        "Email is invalid!",
      ],
    },
    biz_id: { type: Schema.Types.ObjectId, ref: "biz" },
    status: { type: Boolean, default: true },
  },
  { collection: "business", versionKey: false }
);

const Business =
  models.business || model("business", BusinessSchema, "business");

export default Business;
