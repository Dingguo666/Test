"use client";

import { useState, useEffect } from "react";
import { useRouter, useParams } from "next/navigation";
import { Button, TextField, Container } from "@mui/material";
import ResponsiveHeader from "@/components/ResponsiveHeader";
import SendIcon from "@mui/icons-material/Send";
import { styled } from "@mui/system";

const Background = styled("div")({
  backgroundColor: '#e8e8e6',
  backgroundRepeat: "no-repeat",
  backgroundSize: "cover",
  height: "100vh",
});

const EditBiz = () => {
  const router = useRouter();
  const { id } = useParams("id");

  const [bizName, setBizName] = useState("");
  const [street, setStreet] = useState("");
  const [city, setCity] = useState("");
  const [province, setProvince] = useState("");
  const [postalCode, setPostalCode] = useState("");
  const [contactPerson, setContactPerson] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState("");

  useEffect(() => {
    const fetchBiz = async () => {
      try {
        const response = await fetch(`/api/dashboard/manage_biz/crud/${id}`);
        const biz = await response.json();

        setBizName(biz.biz_name);
        setStreet(biz.street);
        setCity(biz.city);
        setProvince(biz.province);
        setPostalCode(biz.postal_code);
        setContactPerson(biz.contact_person);
        setPhoneNumber(biz.phone_number);
        setEmail(biz.email);
        setStatus(biz.status);
      } catch (error) {
        console.error("Error:", error);
      }
    };

    if (id) {
      fetchBiz();
    }
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch(`/api/dashboard/manage_biz/crud/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          biz_name: bizName,
          street,
          city,
          province,
          postal_code: postalCode,
          contact_person: contactPerson,
          phone_number: phoneNumber,
          email,
          status,
        }),
      });

      if (res.ok) {
        alert("BIA updated successfully");
        router.push("/dashboard/manage_biz");
      } else {
        const errorData = await res.json();
        alert(errorData.message);
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  return (
    <body style={{ margin: "0", padding: "0" }}>
      <Background>
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            minHeight: "50vh",
          }}
        >
          <div>
            <div style={{ margin: "15px" }}>
              <ResponsiveHeader>Edit Business Improvement Area</ResponsiveHeader>
            </div>
            <Container>
              <form onSubmit={handleSubmit}>
                  <TextField
                    label="BIA Name"
                    value={bizName}
                    onChange={(e) => setBizName(e.target.value)}
                    style={{ width: "400px" }}
                    sx={{ my: "12px" }}
                  />
                  <br/>
                  <TextField
                    label="Street"
                    value={street}
                    onChange={(e) => setStreet(e.target.value)}
                    style={{ width: "400px" }}
                    sx={{ my: "12px" }}
                  />
                  <br />
                  <TextField
                    label="City"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    style={{ width: "400px" }}
                    sx={{ my: "12px" }}
                  />
                  <br />
                  <TextField
                    label="Province"
                    value={province}
                    onChange={(e) => setProvince(e.target.value)}
                    style={{ width: "400px" }}
                    sx={{ my: "12px" }}
                  />
                  <br />
                  <TextField
                  label="Postal Code"
                  value={postalCode}
                  onChange={(e) => setPostalCode(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                />
                <br />
                  <TextField
                  label="Contact Person"
                  value={contactPerson}
                  onChange={(e) => setContactPerson(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                />
                <br />
                  <TextField
                    label="Phone Number"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    style={{ width: "400px" }}
                    sx={{ my: "12px" }}
                  />
                  <br />
                  <TextField
                    label="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    style={{ width: "400px" }}
                    sx={{ my: "12px" }}
                  />
                  <br />
                <Button
                  type="submit"
                  variant="contained"
                  endIcon={<SendIcon />}
                  sx={{
                    m: 1,
                    p: 2,
                    display: "flex",
                  }}
                >
                  Update
                </Button>
              </form>
            </Container>
          </div>
        </div>
      </Background>
    </body>
  );
};

export default EditBiz;
