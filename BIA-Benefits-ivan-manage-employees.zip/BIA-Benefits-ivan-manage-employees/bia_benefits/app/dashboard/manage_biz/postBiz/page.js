"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button, TextField, Container } from "@mui/material";
import ResponsiveHeader from "@/components/ResponsiveHeader";
import SendIcon from "@mui/icons-material/Send";
import { styled } from "@mui/system";

const Background = styled("div")({
  backgroundColor: "#e8e8e6",
  backgroundRepeat: "no-repeat",
  backgroundSize: "cover",
  height: "100vh",
});

const PostBiz = () => {
  const [bizName, setBizName] = useState("");
  const [street, setStreet] = useState("");
  const [city, setCity] = useState("");
  const [province, setProvince] = useState("");
  const [postalCode, setPostalCode] = useState("");
  const [contactPerson, setContactPerson] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState("");
  const router = useRouter();

  const handleSubmit = async (event) => {
    event.preventDefault();

    const bizData = {
      biz_name: bizName,
      street,
      city,
      province,
      postal_code: postalCode,
      contact_person: contactPerson,
      phone_number: phoneNumber,
      email,
      status: true,
    };

    try {
      const res = await fetch("/api/dashboard/manage_biz/crud/post", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(bizData),
      });
      const data = await res.json();

      if (res.status !== 200) {
        alert(data.message);
      }

      // Use router.push to navigate to the getBizes page
      if (res.status === 200) {
        alert("Success!");
        router.push("/dashboard/manage_biz");
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  return (
    <Background>
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          minHeight: "50vh",
        }}
      >
        <div>
          <div style={{ margin: "15px" }}>
            <ResponsiveHeader>
            Register a Business Improvement Area
            </ResponsiveHeader>
          </div>
          <Container>
            <form onSubmit={handleSubmit}>
              <TextField
                label="BIA Name"
                value={bizName}
                onChange={(e) => setBizName(e.target.value)}
                style={{ width: "400px" }}
                sx={{ my: "12px" }}
              />
              <br />
              <TextField
                label="Street"
                value={street}
                onChange={(e) => setStreet(e.target.value)}
                style={{ width: "400px" }}
                sx={{ my: "12px" }}
              />
              <br />
              <TextField
                label="City"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                style={{ width: "400px" }}
                sx={{ my: "12px" }}
              />
              <br />
              <TextField
                label="Province"
                value={province}
                onChange={(e) => setProvince(e.target.value)}
                style={{ width: "400px" }}
                sx={{ my: "12px" }}
              />
              <br />
              <TextField
                  label="Postal Code"
                  value={postalCode}
                  onChange={(e) => setPostalCode(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                />
                <br />
              <TextField
                  label="Contact Person"
                  value={contactPerson}
                  onChange={(e) => setContactPerson(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                />
                <br />
              <TextField
                label="Phone Number"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                style={{ width: "400px" }}
                sx={{ my: "12px" }}
              />
              <br />
              <TextField
                label="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                style={{ width: "400px" }}
                sx={{ my: "12px" }}
              />
              <br />
              <Button
                type="submit"
                variant="contained"
                endIcon={<SendIcon />}
                sx={{
                  m: 1,
                  p: 2,
                  display: "flex",
                }}
              >
                Register
              </Button>
            </form>
          </Container>
        </div>
      </div>
    </Background>
  );
};

export default PostBiz;
