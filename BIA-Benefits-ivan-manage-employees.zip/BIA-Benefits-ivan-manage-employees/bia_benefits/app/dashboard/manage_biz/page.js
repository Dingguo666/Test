"use client";

import { DataGrid } from "@mui/x-data-grid";
import { Grid } from "@mui/material";
import Paper from "@mui/material/Paper";
import CustomResponsiveFontSizes from "@/components/ResponsiveHeader";
import { useEffect, useState } from "react";
import { Button, styled } from "@mui/material";
import { useRouter } from "next/navigation";
import ControlledSwitches from "@/components/ChangeStatus";
import DeleteModal from "@/components/DeleteModal";
import DeleteIcon from "@mui/icons-material/Delete";
import ResponsiveNav from "@/components/ResponsiveNav";
import { CSVLink } from "react-csv";
import DashboardDrawer from "@/components/dashboard-admin";
import Papa from "papaparse";

const Bizes = () => {
  const [bizesData, setBizesData] = useState([]);
  const [selectedBizes, setSelectedBizes] = useState([]);
  const [openDeleteModal, setOpenDeleteModal] = useState(false);
  const [bizToDelete, setBizToDelete] = useState(null);

  // Set the useState for getting the CSV data
  const [areas, setAreas] = useState([]);

  // Set the header for CSV file
  const headers = [
    { label: "Name", key: "biz_name" },
    { label: "Street", key: "street" },
    { label: "City", key: "city" },
    { label: "Province", key: "province" },
    { label: "Postal Code", key: "postal_code" },
    { label: "Contact Person", key: "contact_person" },
    { label: "Phone Number", key: "phone_number" },
    { label: "Email", key: "email" },
    { label: "Status", key: "status" },
  ];

  //Upload CSV file
  const UploadFile = (event) => {
    event.preventDefault();
    Papa.parse(event.target.files[0], {
      header: true,
      skipEmptyLines: true,
      complete: function (result) {
        const valuesArray = [];
        result.data.map((d) => {
          valuesArray.push(Object.values(d));
        });
        passingData(valuesArray);
        location.reload();
      },
    });
  };

  const passingData = async (valuesArray) => {
    try {
      const transformedData = valuesArray.map((item) => {
        return item.map((value) => {
          if (value === "TRUE") {
            return true;
          } else if (value === "FALSE") {
            return false;
          }
          return value;
        });
      });
      console.log(transformedData);
      const addTitle = transformedData.map(
        ([biz_name, street, city, province, phone_number, email, status]) => ({
          biz_name,
          street,
          city,
          province,
          phone_number,
          email,
          status,
        })
      );
      const goodData = JSON.stringify(addTitle);
      console.log(goodData);
      const response = await fetch("/api/csv/csv_upload_biz", {
        method: "POST",
        body: goodData,
      });
    } catch (error) {
      console.log(error);
    }
  };

  // button for input
  const Input = styled("input")({
    display: "none",
  });

  const router = useRouter();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch("/api/dashboard/manage_biz/getBiz");
        const bizData = await res.json();
        const dataWithIdStrings = bizData.bizList.map((row) => ({
          ...row,
          id: row._id.toString(),
        }));
        setBizesData(dataWithIdStrings);

        // get CSV data of ares
        let areaData = [];
        for (const item of bizData.bizList) {
          let object = {
            biz_name: item.biz_name,
            street: item.street,
            city: item.city,
            province: item.province,
            postal_code: item.postal_code,
            contact_person: item.contact_person,
            phone_number: item.phone_number,
            email: item.email,
            status: item.status,
          };
          areaData.push(object);
        }
        setAreas(areaData);
      } catch (error) {
        alert(error);
      }
    };
    fetchData();
  }, []);

  const columns = [
    { field: "biz_name", headerName: "Name", flex: 1 },
    { field: "street", headerName: "Street", flex: 1.5 },
    { field: "city", headerName: "City", flex: 1.5 },
    { field: "province", headerName: "Province", flex: 1.5 },
    { field: "postal_code", headerName: "Postal Code", flex: 0.5 },
    { field: "contact_person", headerName: "Contact Person", flex: 1 },
    { field: "phone_number", headerName: "Phone Number", flex: 1 },
    { field: "email", headerName: "Email", flex: 1 },
    {
      field: "status",
      headerName: "Status",
      flex: 0.5,
      renderCell: (params) => (
        <ControlledSwitches
          status={params.row.status}
          changeStatus={async (newStatus) => {
            try {
              // update status in the database
              const response = await fetch(
                `/api/dashboard/manage_biz/switch/${params.row.id}`,
                {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json",
                  },
                  body: JSON.stringify({
                    id: params.row.id,
                    status: newStatus,
                  }),
                }
              );

              if (!response.ok)
                throw new Error(`HTTP error! status: ${response.status}`);
              // update status in local state
              setBizesData(
                bizesData.map((biz) =>
                  biz.id === params.row.id ? { ...biz, status: newStatus } : biz
                )
              );
            } catch (error) {
              console.error("Failed to update status:", error);
            }
          }}
        />
      ),
    },
  ];

  const createNewBiz = () => {
    router.push(`/dashboard/manage_biz/postBiz`);
  };

  const editBiz = () => {
    if (selectedBizes.length === 1) {
      router.push(`/dashboard/manage_biz/editBiz/${selectedBizes[0]}`);
    } else {
      alert("Please select a single row to edit");
    }
  };

  const deleteBiz = () => {
    if (selectedBizes.length === 1) {
      setBizToDelete(selectedBizes[0]);
      setOpenDeleteModal(true);
    } else {
      alert("Please select a single row to delete");
    }
  };

  const handleDelete = async () => {
    try {
      const res = await fetch(`/api/dashboard/manage_biz/crud/${bizToDelete}`, {
        method: "DELETE",
      });

      if (!res.ok) throw res;
      setBizesData(bizesData.filter((cp) => cp.id !== bizToDelete));
      setSelectedBizes([]);
      setBizToDelete(null);
      setOpenDeleteModal(false);
    } catch (error) {
      console.log("Failed to delete the BIZ:", error);
    }
  };

  return (
    <div style={{ height: 600, width: "100%" }}>
      <ResponsiveNav />
      <DeleteModal
        open={openDeleteModal}
        handleClose={() => setOpenDeleteModal(false)}
        handleDelete={handleDelete}
      />
      <CustomResponsiveFontSizes>Managing BIAs</CustomResponsiveFontSizes>
      <Grid sx={{ m: 1, p: 1 }}>
        <DashboardDrawer />
        <Button
          variant="contained"
          color="success"
          onClick={createNewBiz}
          sx={{ m: 1, p: 2 }}
        >
          New BIA
        </Button>
        <Button variant="contained" onClick={editBiz} sx={{ m: 1, p: 2 }}>
          Edit Selected BIA
        </Button>
        <Button
          variant="outlined"
          color="error"
          startIcon={<DeleteIcon />}
          onClick={deleteBiz}
          sx={{ m: 1, p: 2 }}
        >
          Delete Selected BIA
        </Button>
        <CSVLink
          data={areas}
          headers={headers}
          filename="BIAs.csv"
          style={{ textDecoration: "none" }}
        >
          <Button variant="contained" color="success" sx={{ m: 1, p: 2 }}>
            Generate Report
          </Button>
        </CSVLink>
        <Button variant="contained" sx={{ m: 1, p: 1 }}>
          <label htmlFor="contained-button-file">
            <Input
              accept=".csv"
              id="contained-button-file"
              type="file"
              onChange={UploadFile}
            />
            <Button variant="contained" component="span">
              Upload CSV
            </Button>
          </label>
        </Button>
      </Grid>
      <Grid>
        <DataGrid
          rows={bizesData}
          columns={columns}
          onRowSelectionModelChange={(newSelection) => {
            setSelectedBizes(newSelection);
          }}
          pageSize={5}
          rowsPerPageOptions={[5]}
          checkboxSelection
          getRowId={(row) => row._id}
          component={Paper}
          style={{
            margin: "0 auto",
            backgroundColor: "#e8e8e6",
            borderRadius: "10px",
          }}
          disableRowSelectionOnClick
        />
      </Grid>
    </div>
  );
};

export default Bizes;
