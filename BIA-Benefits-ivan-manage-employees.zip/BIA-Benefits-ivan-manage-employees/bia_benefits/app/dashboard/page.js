"use client";

import { useState, useEffect } from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import ResponsiveHeader from "@/components/ResponsiveHeader";
import { Grid } from "@mui/material";
import Link from "next/link";
import ClientOnly from "@/components/clientOnly";
import ResponsiveNav from "@/components/ResponsiveNav";
import { CSVLink } from 'react-csv';

export default function DashBoard() {
  const [bizCount, setBizCount] = useState(0);
  const [corpPartnCount, setcorpPartnCount] = useState(0);
  const [biaEmpCount, setBiaEmpCount] = useState(0);
  const [busCount, setBusCount] = useState(0);


  // Set the useState for getting the CSV data
  const[employees,setEmployees]=useState([]);
  const[partners,setPartners]=useState([]);
  const[areas,setAreas] = useState([]);
  const[business,setBusiness] = useState([]);

  //count
  useEffect(() => {
    const fetchData = async () => {
      try {
        const bizs = await fetch("/api/dashboard/manage_biz/getBiz");
        const corPart = await fetch("/api/dashboard/corporate_partners/getCP");
        const biaEmp = await fetch("/api/dashboard/bia_employees/get");
        const buss = await fetch("/api/dashboard/manage_business/getBus");

        const bizData = await bizs.json();
        const corpPartData = await corPart.json();
        const biaEmpData = await biaEmp.json();
        const busData = await buss.json();

        // get CSV data of employees 
        let employData =[];
        for(const item of biaEmpData.biaEmployeeList){
          let object ={
            employee_name:  item.employee_name,
            employee_email: item.employee_email,
            user_type: item.user_type,
            status: item.status
          }
          employData.push(object);
        }
        setEmployees(employData);

        // get CSV data of partners
        let partnerData =[];
        for(const item of corpPartData.corpPartnerList){
          let object ={
            partner_name:  item.partner_name,
            street: item.street,
            city: item.city,
            province: item.province,
            contact_person: item.contact_person,
            phone_number:item.phone_number,
            email:item.email,
            status:item.status
          }
          partnerData.push(object);
        }
        setPartners(partnerData);

        // get CSV data of areas
        let areaData =[];
        for(const item of bizData.bizList){
          let object ={
            biz_name:  item.biz_name,
            street: item.street,
            city: item.city,
            province: item.province,
            contact_person: item.contact_person,
            phone_number:item.phone_number,
            email:item.email,
            status:item.status
          }
          areaData.push(object);
        }
        setAreas(areaData);

          // get CSV data of businesses
          let businessData =[];
          for(const item of busData.busList){
            let object ={
              biz_ui:  item.biz_ui,
              business_ui:  item.business_ui,
              business_name: item.business_name,
              street: item.street,
              city: item.city,
              province: item.province,
              contact_person: item.contact_person,
              phone_number:item.phone_number,
              email:item.email,
              status:item.status
            }
            businessData.push(object);
          }
          setBusiness(businessData);

        // Count the numbers
        setBizCount(bizData.bizList.length);
        setcorpPartnCount(corpPartData.corpPartnerList.length);
        setBiaEmpCount(biaEmpData.biaEmployeeList.length);
        setBusCount(busData.busList.length);
      } catch (error) {
        alert(error);
      }
    };
    fetchData();
  }, []);

  return (
    <div>
      <ResponsiveNav/>
      <ClientOnly>
        <div style={{ margin: "30px", textAlign: "center" }}>
          <ResponsiveHeader>Admin - Dashboard</ResponsiveHeader>
        </div>
        <Grid container justifyContent="center">
          <Grid item>
            <TableContainer component={Paper} style={{ margin: "0 auto", backgroundColor: "#e8e8e6", borderRadius: "10px" }}>
              <Table sx={{ minWidth: 650 }}>
                <TableHead
                  style={{
                    backgroundColor: "#c9foff",
                    fontWeight: "bold",
                    color: "#c9f0ff",
                  }}
                >
                  <TableRow>
                    <TableCell>Name</TableCell>
                    <TableCell align="right">Number</TableCell>
                    <TableCell align="right">Generate Report</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  <TableRow>
                    <TableCell component="th" style={{ fontWeight: "600", color: "#0070F3" }}>
                      <Link href="/dashboard/bia_employees" passHref>
                        BIA Benefits Employees
                      </Link>
                    </TableCell>
                    <TableCell align="right" style={{ fontSize: "17px" }}>
                      {biaEmpCount}
                    </TableCell>
                    <TableCell align="right" style={{ color: "#0070F3", fontWeight: "600" }}>
                      <CSVLink data={employees} filename="BIA employees">Generate Report</CSVLink>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell component="th" style={{ fontWeight: "600", color: "#0070F3" }}>
                      <Link href="/dashboard/corporate_partners" passHref>
                        Corporate partners
                      </Link>
                    </TableCell>
                    <TableCell align="right" style={{ fontSize: "17px" }}>
                      {corpPartnCount}
                    </TableCell>
                    <TableCell align="right" style={{ color: "#0070F3", fontWeight: "600" }}>
                      <CSVLink data={partners} filename="BIA partners">Generate Report</CSVLink>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell component="th" style={{ fontWeight: "600", color: "#0070F3"}}>
                      <Link href="/dashboard/manage_biz" passHref>
                      Business Improvement Areas
                      </Link>
                    </TableCell>
                    <TableCell align="right" style={{ fontSize: "17px" }}>
                      {bizCount}
                    </TableCell>
                    <TableCell align="right" style={{ color: "#0070F3", fontWeight: "600" }}>
                      <CSVLink data={areas} filename="BIA ares">Generate Report</CSVLink>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell component="th" style={{ fontWeight: "600", color: "#0070F3"}}>
                      <Link href="/dashboard/manage_business" passHref>
                      Businesses
                      </Link>
                    </TableCell>
                    <TableCell align="right" style={{ fontSize: "17px" }}>
                      {busCount}
                    </TableCell>
                    <TableCell align="right" style={{ color: "#0070F3", fontWeight: "600" }}>
                      <CSVLink data={business} filename="Businesses">Generate Report</CSVLink>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </Grid>
        </Grid>
      </ClientOnly>
    </div>
  );
}
