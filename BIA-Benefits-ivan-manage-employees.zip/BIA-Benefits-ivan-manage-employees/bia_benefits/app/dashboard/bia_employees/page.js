"use client";

import { DataGrid } from "@mui/x-data-grid";
import { Grid } from "@mui/material";
import Paper from "@mui/material/Paper";
import CustomResponsiveFontSizes from "@/components/ResponsiveHeader";
import { useEffect, useState } from "react";
import { Button, styled } from "@mui/material";
import { useRouter } from "next/navigation";
import ControlledSwitches from "@/components/ChangeStatus";
import DeleteModal from "@/components/DeleteModal";
import DeleteIcon from "@mui/icons-material/Delete";
import ResponsiveNav from "@/components/ResponsiveNav";
import { CSVLink } from "react-csv";
import DashboardDrawer from "@/components/dashboard-admin";
import Papa from "papaparse";

const BiaEmployees = () => {
  const [biaEmpData, setBiaEmpData] = useState([]);
  const [selectedBiaEmp, setSelectedBiaEmp] = useState([]);
  const [openDeleteModal, setOpenDeleteModal] = useState(false);
  const [biaEmpToDelete, setBiaEmpToDelete] = useState(null);

  // Set the useState for getting the CSV data
  const [employees, setEmployees] = useState([]);

  // Set the header for CSV file
  const headers = [
    { label: "Name", key: "employee_name" },
    { label: "Email", key: "employee_email" },
    { label: "User Type", key: "user_type" },
    { label: "Status", key: "status" },
  ];

  const router = useRouter();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch("/api/dashboard/bia_employees/get");
        const biaEmpData = await res.json();
        const dataWithIdStrings = biaEmpData.biaEmployeeList.map((row) => ({
          ...row,
          id: row._id.toString(),
        }));
        setBiaEmpData(dataWithIdStrings);

        // get CSV data of employees
        let employData = [];
        for (const item of biaEmpData.biaEmployeeList) {
          let object = {
            employee_name: item.employee_name,
            employee_email: item.employee_email,
            user_type: item.user_type,
            status: item.status,
          };
          employData.push(object);
        }
        setEmployees(employData);
      } catch (error) {
        alert(error);
      }
    };
    fetchData();
  }, []);

  // upload CSV file
  const UploadFile = (event) => {
    event.preventDefault();
    Papa.parse(event.target.files[0], {
      header: true,
      skipEmptyLines: true,
      complete: function (result) {
        const valuesArray = [];
        result.data.map((d) => {
          valuesArray.push(Object.values(d));
        });
        passingData(valuesArray);
        location.reload();
      },
    });
  };

  const passingData = async (valuesArray) => {
    try {
      const transformedData = valuesArray.map((item) => {
        return item.map((value) => {
          if (value === "TRUE") {
            return true;
          } else if (value === "FALSE") {
            return false;
          }
          return value;
        });
      });
      const addTitle = transformedData.map(
        ([employee_name, employee_email, user_type, status]) => ({
          employee_name,
          employee_email,
          user_type,
          status,
        })
      );
      const goodData = JSON.stringify(addTitle);
      console.log(goodData);
      const response = await fetch(`/api/csv/csv_upload_employee`, {
        method: "POST",
        body: goodData,
      });
    } catch (error) {
      console.log(error);
    }
  };

  // button for input
  const Input = styled("input")({
    display: "none",
  });

  // creating a variable with all table colums headings
  const columns = [
    { field: "employee_name", headerName: "Name", flex: 1 },
    { field: "employee_email", headerName: "Email", flex: 1 },
    { field: "user_type", headerName: "User Type", flex: 1 },

    //switch changes 'status' when clicked
    {
      field: "status",
      headerName: "Status",
      flex: 0.5,
      renderCell: (params) => (
        <ControlledSwitches
          status={params.row.status}
          changeStatus={async (newStatus) => {
            try {
              // update status in the database
              const response = await fetch(
                `/api/dashboard/bia_employees/switch/${params.row.id}`,
                {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json",
                  },
                  body: JSON.stringify({
                    id: params.row.id,
                    status: newStatus,
                  }),
                }
              );

              if (!response.ok)
                throw new Error(`HTTP error! status: ${response.status}`);

              // update status in local state
              setBiaEmpData(
                biaEmpData.map((biaEm) =>
                  biaEm.id === params.row.id
                    ? { ...biaEm, status: newStatus }
                    : biaEm
                )
              );
            } catch (error) {
              console.error("Failed to update status:", error);
            }
          }}
        />
      ),
    },
  ];

  // function to redirect to 'NEW EMPLOYEE'
  const createNewBiaEmp = () => {
    router.push(`/dashboard/bia_employees/postBiaEmp`);
  };

  // function to redirect to 'EDIT EMPLOYEE'
  const editBiaEmp = () => {
    if (selectedBiaEmp.length === 1) {
      router.push(`/dashboard/bia_employees/edit/${selectedBiaEmp[0]}`);
    } else {
      alert("Please select a single row to edit");
    }
  };

  // function 'DELETE EMPLOYEE' that is called on this page
  const deleteBiaEmp = () => {
    if (selectedBiaEmp.length === 1) {
      setBiaEmpToDelete(selectedBiaEmp[0]);
      setOpenDeleteModal(true);
    } else {
      alert("Please select a single row to delete");
    }
  };

  const handleDelete = async () => {
    try {
      const res = await fetch(
        `/api/dashboard/bia_employees/crud/${biaEmpToDelete}`,
        {
          method: "DELETE",
        }
      );

      if (!res.ok) throw res;
      setBiaEmpData(
        biaEmpData.filter((biaEmp) => biaEmp.id !== biaEmpToDelete)
      );
      setSelectedBiaEmp([]);
      setBiaEmpToDelete(null);
      setOpenDeleteModal(false);
    } catch (error) {
      console.log("Failed to delete the employee:", error);
    }
  };

  return (
    <div style={{ height: 500, width: "100%" }}>
      <ResponsiveNav />
      <DeleteModal
        open={openDeleteModal}
        handleClose={() => setOpenDeleteModal(false)}
        handleDelete={handleDelete}
      />
      <CustomResponsiveFontSizes>
        BIA Benefits Employees
      </CustomResponsiveFontSizes>
      <Grid sx={{ m: 1, p: 1 }}>
        <DashboardDrawer />
        <Button
          variant="contained"
          color="success"
          onClick={createNewBiaEmp}
          sx={{ m: 1, p: 2 }}
        >
          New Employee
        </Button>
        <Button variant="contained" onClick={editBiaEmp} sx={{ m: 1, p: 2 }}>
          Edit Employee
        </Button>
        <Button
          variant="outlined"
          color="error"
          startIcon={<DeleteIcon />}
          onClick={deleteBiaEmp}
          sx={{ m: 1, p: 2 }}
        >
          Delete Employee
        </Button>
        <CSVLink
          data={employees}
          headers={headers}
          filename="BIA_employees.csv"
          style={{ textDecoration: "none" }}
        >
          <Button variant="contained" color="success" sx={{ m: 1, p: 2 }}>
            Generate Report
          </Button>
        </CSVLink>
        <Button variant="contained" sx={{ m: 1, p: 1 }}>
          <label htmlFor="contained-button-file">
            <Input
              accept=".csv"
              id="contained-button-file"
              type="file"
              onChange={UploadFile}
            />
            <Button variant="contained" component="span">
              Upload CSV
            </Button>
          </label>
        </Button>
      </Grid>
      <Grid>
        <DataGrid
          rows={biaEmpData}
          columns={columns}
          onRowSelectionModelChange={(newSelection) => {
            setSelectedBiaEmp(newSelection);
          }}
          pageSize={5}
          rowsPerPageOptions={[5]}
          checkboxSelection
          getRowId={(row) => row._id}
          component={Paper}
          style={{
            margin: "0 auto",
            backgroundColor: "#e8e8e6",
            borderRadius: "10px",
          }}
          disableRowSelectionOnClick
        />
      </Grid>
    </div>
  );
};

export default BiaEmployees;
