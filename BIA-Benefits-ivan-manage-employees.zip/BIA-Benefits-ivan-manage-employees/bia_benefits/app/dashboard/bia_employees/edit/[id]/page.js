"use client";

import { useState, useEffect } from "react";
import { useRouter, useParams } from "next/navigation";
import { Button, TextField, Container } from "@mui/material";
import ResponsiveHeader from "@/components/ResponsiveHeader";
import SendIcon from "@mui/icons-material/Send";
import { styled } from "@mui/system";

const Background = styled("div")({
  backgroundColor: "#e8e8e6",
  backgroundRepeat: "no-repeat",
  backgroundSize: "cover",
  height: "100vh",
});

const EditBiaEmp = () => {
  const router = useRouter();
  const { id } = useParams("id");

  const [biaEmpName, setBiaEmpName] = useState("");
  const [email, setEmail] = useState("");
  const [type, setType] = useState("");
  const [status, setStatus] = useState("");

  useEffect(() => {
    const fetchbiaEmp = async () => {
      try {
        const response = await fetch(`/api/dashboard/bia_employees/crud/${id}`);
        const biaEmp = await response.json();

        setBiaEmpName(biaEmp.employee_name);
        setEmail(biaEmp.employee_email);
        setType(biaEmp.user_type);
        setStatus(biaEmp.status);
      } catch (error) {
        console.error("Error:", error);
      }
    };

    if (id) {
      fetchbiaEmp();
    }
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch(`/api/dashboard/bia_employees/crud/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          employee_name: biaEmpName,
          employee_email: email,
          user_type: type,
          status: status,
        }),
      });

      if (res.ok) {
        alert("Employee updated successfully");
        router.push("/dashboard/bia_employees");
      } else {
        const errorData = await res.json();
        alert(errorData.message);
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  return (
    <body style={{ margin: "0", padding: "0" }}>
      <Background>
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            minHeight: "50vh",
          }}
        >
          <div>
            <div style={{ margin: "15px" }}>
              <ResponsiveHeader>Edit BIA Benefits Employee</ResponsiveHeader>
            </div>
            <Container>
              <form onSubmit={handleSubmit}>
                <TextField
                  label="Employee Name"
                  value={biaEmpName}
                  onChange={(e) => setBiaEmpName(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                /><br/>
                <TextField
                  label="Email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                /><br/>
                <TextField
                  label="User Type"
                  value={type}
                  onChange={(e) => setType(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                /><br/>
                <Button
                  type="submit"
                  variant="contained"
                  endIcon={<SendIcon />}
                  sx={{
                    m: 1,
                    p: 2,
                    display: "flex",
                  }}
                >
                  Update
                </Button>
              </form>
            </Container>
          </div>
        </div>
      </Background>
    </body>
  );
};

export default EditBiaEmp;
