"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button, TextField, Container } from "@mui/material";
import ResponsiveHeader from '@/components/ResponsiveHeader';
import SendIcon from "@mui/icons-material/Send";
import { styled } from "@mui/system";

const Background = styled("div")({
  backgroundColor: "#e8e8e6",
  backgroundRepeat: "no-repeat",
  backgroundSize: "cover",
  height: "100vh",
});

const PostBiaEmp = () => {
  const [biaEmpName, setBiaEmpName] = useState("");
  const [email, setEmail] = useState("");
  const [type, setType] = useState("");
  const [status, setStatus] = useState("");
  const router = useRouter();

  const handleSubmit = async (event) => {
    event.preventDefault();

    const biaEmpData = {
      employee_name: biaEmpName,
      employee_email: email,
      user_type: type,
      status: true,
    };

    try {
      const res = await fetch("/api/dashboard/bia_employees/crud/post", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(biaEmpData),
      });
      const data = await res.json();

      if (res.status !== 200) {
        alert(data.message);
      }

      // Use router.push to navigate to the bia_employees page
      if (res.status === 200) {
        alert("Success!");
        router.push("/dashboard/bia_employees");
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  return (
    <body style={{ margin: "0", padding: "0" }}>
      <Background>
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            minHeight: "50vh",
          }}
        >
          <div>
            <div style={{ margin: "15px" }}>
        <ResponsiveHeader>Register a new BIA Benefits Employee</ResponsiveHeader>
      </div>
      <Container>
              <form onSubmit={handleSubmit}>
                <TextField
                  label="Employee Name"
                  value={biaEmpName}
                  onChange={(e) => setBiaEmpName(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                /><br/>
                <TextField
                  label="Email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                /><br/>
                <TextField
                  label="User Type"
                  value={type}
                  onChange={(e) => setType(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                /><br/>
                <Button
                  type="submit"
                  variant="contained"
                  endIcon={<SendIcon />}
                  sx={{
                    m: 1,
                    p: 2,
                    display: "flex",
                  }}
                >
                  Register
                </Button>
              </form>
            </Container>
          </div>
        </div>
      </Background>
    </body>
  );
};

export default PostBiaEmp;
