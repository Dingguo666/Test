export default function Layout({ children }) {
  return (
    <html lang="en">
      <body style={{margin: "8px"}}>
        { children }
      </body>
    </html>
  );
}
