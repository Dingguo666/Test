"use client";

import { useState, useEffect } from "react";
import { useRouter, useSearchParams, useParams } from "next/navigation";
import { Button, TextField, Container } from "@mui/material";
import SendIcon from "@mui/icons-material/Send";
import ResponsiveHeader from "@/components/ResponsiveHeader";
import { styled } from "@mui/system";

const Background = styled("div")({
  backgroundColor: "#e8e8e6",
  backgroundRepeat: "no-repeat",
  backgroundSize: "cover",
  height: "100vh",
});

const EditcorpPart = () => {
  const router = useRouter();
  const { id } = useParams("id");

  const [corpPartnerName, setcorpPartnerName] = useState("");
  const [street, setStreet] = useState("");
  const [city, setCity] = useState("");
  const [province, setProvince] = useState("");
  const [postalCode, setPostalCode] = useState("");
  const [contactPerson, setContactPerson] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState("");

  useEffect(() => {
    const fetchcorpPart = async () => {
      try {
        const response = await fetch(`/api/dashboard/corporate_partners/crud/${id}`);
        const corpPart = await response.json();

        setcorpPartnerName(corpPart.partner_name);
        setStreet(corpPart.street);
        setCity(corpPart.city);
        setProvince(corpPart.province);
        setPostalCode(corpPart.postal_code);
        setContactPerson(corpPart.contact_person);
        setPhoneNumber(corpPart.phone_number);
        setEmail(corpPart.email);
        setStatus(corpPart.status);
      } catch (error) {
        console.error("Error:", error);
      }
    };

    if (id) {
      fetchcorpPart();
    }
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch(`/api/dashboard/corporate_partners/crud/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          partner_name: corpPartnerName,
          street,
          city,
          province,
          postal_code: postalCode,
          contact_person: contactPerson,
          phone_number: phoneNumber,
          email,
          status,
        }),
      });

      if (res.ok) {
        alert("Corporate Partner updated successfully");
        router.push("/dashboard/corporate_partners");
      } else {
        const errorData = await res.json();
        alert(errorData.message);
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  return (
    <body style={{ margin: "0", padding: "0" }}>
      <Background>
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            minHeight: "50vh",
          }}
        >
          <div>
            <div style={{ margin: "15px" }}>
              <ResponsiveHeader>Edit Corporate Partner</ResponsiveHeader>
            </div>
            <Container>
              <form onSubmit={handleSubmit}>
                <TextField
                  label="Corporate Partner Name"
                  value={corpPartnerName}
                  onChange={(e) => setcorpPartnerName(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                />
                <br />
                <TextField
                  label="Street"
                  value={street}
                  onChange={(e) => setStreet(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                />
                <br />
                <TextField
                  label="City"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                />
                <br />
                <TextField
                  label="Province"
                  value={province}
                  onChange={(e) => setProvince(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                />
                <br />
                <TextField
                  label="Postal Code"
                  value={postalCode}
                  onChange={(e) => setPostalCode(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                />
                <br />
                <TextField
                  label="Contact Person"
                  value={contactPerson}
                  onChange={(e) => setContactPerson(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                />
                <br />
                <TextField
                  label="Phone Number"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                />
                <br />
                <TextField
                  label="Email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                />
                <br />
                <Button
                  type="submit"
                  variant="contained"
                  endIcon={<SendIcon />}
                  sx={{
                    m: 1,
                    p: 2,
                    display: "flex",
                  }}
                >
                  Update
                </Button>{" "}
              </form>
            </Container>
          </div>
        </div>
      </Background>
    </body>
  );
};

export default EditcorpPart;
