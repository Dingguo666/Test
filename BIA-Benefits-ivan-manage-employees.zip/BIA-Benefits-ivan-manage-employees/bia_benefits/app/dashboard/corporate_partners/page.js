"use client";

import { DataGrid } from "@mui/x-data-grid";
import { Grid } from "@mui/material";
import { Button, styled } from "@mui/material";
import Paper from "@mui/material/Paper";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import CustomResponsiveFontSizes from "@/components/ResponsiveHeader";
import ControlledSwitches from "@/components/ChangeStatus";
import DeleteIcon from "@mui/icons-material/Delete";
import DeleteModal from "@/components/DeleteModal";
import ResponsiveNav from "@/components/ResponsiveNav";
import { CSVLink } from "react-csv";
import DashboardDrawer from "@/components/dashboard-admin";
import Papa from "papaparse";
const CorporatePartnersIndexPage = () => {
  const [corpPartnerData, setcorpPartnerData] = useState([]);
  const [selectedCorpPartners, setselectedCorpPartners] = useState([]);
  const [openDeleteModal, setOpenDeleteModal] = useState(false);
  const [partnerToDelete, setPartnerToDelete] = useState(null);

  // Set the useState for getting the CSV data
  const [partners, setPartners] = useState([]);

  // Set the header for CSV file
  const headers = [
    { label: "Name", key: "partner_name" },
    { label: "Street", key: "street" },
    { label: "City", key: "city" },
    { label: "Province", key: "province" },
    { label: "Postal Code", key: "postal_code" },
    { label: "Phone Number", key: "phone_number" },
    { label: "Contact Person", key: "contact_person" },
    { label: "Email", key: "email" },
    { label: "Status", key: "status" },
  ];

  //Upload CSV file
  const UploadFile = (event) => {
    event.preventDefault();
    Papa.parse(event.target.files[0], {
      header: true,
      skipEmptyLines: true,
      complete: function (result) {
        const valuesArray = [];
        result.data.map((d) => {
          valuesArray.push(Object.values(d));
        });
        passingData(valuesArray);
        location.reload();
      },
    });
  };

  const passingData = async (valuesArray) => {
    try {
      const transformedData = valuesArray.map((item) => {
        return item.map((value) => {
          if (value === "TRUE") {
            return true;
          } else if (value === "FALSE") {
            return false;
          }
          return value;
        });
      });
      console.log(transformedData);
      const addTitle = transformedData.map(
        ([
          partner_name,
          street,
          city,
          province,
          phone_number,
          email,
          status,
        ]) => ({
          partner_name,
          street,
          city,
          province,
          phone_number,
          email,
          status,
        })
      );
      const goodData = JSON.stringify(addTitle);
      console.log(goodData);
      const response = await fetch("/api/csv/csv_upload_partner", {
        method: "POST",
        body: goodData,
      });
    } catch (error) {
      console.log(error);
    }
  };

  // button for input
  const Input = styled("input")({
    display: "none",
  });

  const router = useRouter();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch("/api/dashboard/corporate_partners/getCP");
        const corpPartnData = await res.json();
        const dataWithIdStrings = corpPartnData.corpPartnerList.map((row) => ({
          ...row,
          id: row._id.toString(),
        }));
        setcorpPartnerData(dataWithIdStrings);

        // get CSV data of partners
        let partnerData = [];
        for (const item of corpPartnData.corpPartnerList) {
          let object = {
            partner_name: item.partner_name,
            street: item.street,
            city: item.city,
            province: item.province,
            postal_code: item.postal_code,
            contact_person: item.contact_person,
            phone_number: item.phone_number,
            email: item.email,
            status: item.status,
          };
          partnerData.push(object);
        }

        setPartners(partnerData);
      } catch (error) {
        alert(error);
      }
    };
    fetchData();
  }, []);

  const columns = [
    { field: "partner_name", headerName: "Name", flex: 1 },
    { field: "street", headerName: "Street", flex: 0.5 },
    { field: "city", headerName: "City", flex: 0.5 },
    { field: "province", headerName: "Province", flex: 0.5 },
    { field: "postal_code", headerName: "Postal Code", flex: 0.5 },
    { field: "phone_number", headerName: "Phone Number", flex: 1 },
    { field: "contact_person", headerName: "Contact Person", flex: 1 },
    { field: "email", headerName: "Email", flex: 1 },
    {
      field: "status",
      headerName: "Status",
      flex: 0.5,
      renderCell: (params) => (
        <ControlledSwitches
          status={params.row.status}
          changeStatus={async (newStatus) => {
            try {
              // update status in the database
              const response = await fetch(
                `/api/dashboard/corporate_partners/switch/${params.row.id}`,
                {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json",
                  },
                  body: JSON.stringify({
                    id: params.row.id,
                    status: newStatus,
                  }),
                }
              );

              if (!response.ok)
                throw new Error(`HTTP error! status: ${response.status}`);

              // update status in local state
              setcorpPartnerData(
                corpPartnerData.map((cp) =>
                  cp.id === params.row.id ? { ...cp, status: newStatus } : cp
                )
              );
            } catch (error) {
              console.error("Failed to update status:", error);
            }
          }}
        />
      ),
    },
  ];

  const createNewCP = () => {
    router.push(`/dashboard/corporate_partners/postCP`);
  };

  const editCP = () => {
    if (selectedCorpPartners.length === 1) {
      router.push(
        `/dashboard/corporate_partners/editCP/${selectedCorpPartners[0]}`
      );
    } else {
      alert("Please select a single row to edit");
    }
  };

  const deleteCP = () => {
    if (selectedCorpPartners.length === 1) {
      setPartnerToDelete(selectedCorpPartners[0]);
      setOpenDeleteModal(true);
    } else {
      alert("Please select a single row to delete");
    }
  };

  const handleDelete = async () => {
    try {
      const res = await fetch(
        `/api/dashboard/corporate_partners/crud/${partnerToDelete}`,
        {
          method: "DELETE",
        }
      );

      if (!res.ok) throw res;
      setcorpPartnerData(
        corpPartnerData.filter((cp) => cp.id !== partnerToDelete)
      );
      setselectedCorpPartners([]);
      setPartnerToDelete(null);
      setOpenDeleteModal(false);
    } catch (error) {
      console.log("Failed to delete the partner:", error);
    }
  };

  return (
    <div style={{ height: 500, width: "100%" }}>
      <ResponsiveNav />
      <DeleteModal
        open={openDeleteModal}
        handleClose={() => setOpenDeleteModal(false)}
        handleDelete={handleDelete}
      />
      <CustomResponsiveFontSizes>Corporate Partners</CustomResponsiveFontSizes>
      <Grid sx={{ m: 1, p: 1 }}>
        <DashboardDrawer />
        <Button
          variant="contained"
          color="success"
          onClick={createNewCP}
          sx={{ m: 1, p: 2 }}
        >
          New Partner
        </Button>
        <Button variant="contained" onClick={editCP} sx={{ m: 1, p: 2 }}>
          Edit Partner
        </Button>
        <Button
          variant="outlined"
          color="error"
          startIcon={<DeleteIcon />}
          onClick={deleteCP}
          sx={{ m: 1, p: 2 }}
        >
          Delete Partner
        </Button>
        <CSVLink
          data={partners}
          headers={headers}
          filename="BIA_partners.csv"
          style={{ textDecoration: "none" }}
        >
          <Button variant="contained" color="success" sx={{ m: 1, p: 2 }}>
            Generate Report
          </Button>
        </CSVLink>
        <Button variant="contained" sx={{ m: 1, p: 1 }}>
          <label htmlFor="contained-button-file">
            <Input
              accept=".csv"
              id="contained-button-file"
              type="file"
              onChange={UploadFile}
            />
            <Button variant="contained" component="span">
              Upload CSV
            </Button>
          </label>
        </Button>
      </Grid>
      <Grid>
        <DataGrid
          rows={corpPartnerData}
          columns={columns}
          onRowSelectionModelChange={(newSelection) => {
            setselectedCorpPartners(newSelection);
          }}
          pageSize={5}
          rowsPerPageOptions={[5]}
          checkboxSelection
          getRowId={(row) => row._id}
          component={Paper}
          style={{
            margin: "0 auto",
            backgroundColor: "#e8e8e6",
            borderRadius: "10px",
          }}
          disableRowSelectionOnClick
        />
      </Grid>
    </div>
  );
};

export default CorporatePartnersIndexPage;
