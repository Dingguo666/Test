"use client";

import { DataGrid } from "@mui/x-data-grid";
import { Grid } from "@mui/material";
import Paper from "@mui/material/Paper";
import CustomResponsiveFontSizes from "@/components/ResponsiveHeader";
import { useEffect, useState } from "react";
import { Button, styled } from "@mui/material";
import { useRouter } from "next/navigation";
import ControlledSwitches from "@/components/ChangeStatus";
import DeleteModal from "@/components/DeleteModal";
import DeleteIcon from "@mui/icons-material/Delete";
import ResponsiveNav from "@/components/ResponsiveNav";
import { CSVLink } from "react-csv";
import DashboardDrawer from "@/components/dashboard-admin";
import Papa from "papaparse";
import ClientOnly from "@/components/clientOnly";

const Employees = () => {
  const [empData, setEmpData] = useState([]);
  const [selectedEmp, setSelectedEmp] = useState([]);
  const [openDeleteModal, setOpenDeleteModal] = useState(false);
  const [empToDelete, setEmpToDelete] = useState(null);

  // Set the useState for getting the CSV data
  const [employees, setEmployees] = useState([]);

  // Set the header for CSV file
  const headers = [
    {label: "BIZ Identifier", key: "biz_ui"},
    {label: "Business Identifier", key: "business_ui"},
    {label: "Employee Identifier", key: "employee_ui"},
    { label: "Name", key: "business_name" },
    { label: "Street", key: "street" },
    { label: "City", key: "city" },
    { label: "Province", key: "province" },
    { label: "Postal Code", key: "postal_code" },
    { label: "Email", key: "email" },
    { label: "Status", key: "status" },
  ];

  //Upload CSV file
  const UploadFile = (event) => {
    event.preventDefault();
    Papa.parse(event.target.files[0], {
      header: true,
      skipEmptyLines: true,
      complete: function (result) {
        const valuesArray = [];
        result.data.map((d) => {
          valuesArray.push(Object.values(d));
        });
        passingData(valuesArray);
        location.reload();
      },
    });
  };

  const passingData = async (valuesArray) => {
    try {
      const transformedData = valuesArray.map((item) => {
        return item.map((value) => {
          if (value === "TRUE") {
            return true;
          } else if (value === "FALSE") {
            return false;
          }
          return value;
        });
      });
      console.log(transformedData);
      const addTitle = transformedData.map(
        ([biz_ui, business_ui, employee_ui, name, street, city, province, email, status]) => ({
          biz_ui, 
          business_ui,
          employee_ui,
          name,
          street,
          city,
          province,
          email,
          status,
        })
      );
      const goodData = JSON.stringify(addTitle);
      console.log(goodData);
      
      // !!change this
      const response = await fetch("/api/csv/csv_upload_employees", {
        method: "POST",
        body: goodData,
      });
    } catch (error) {
      console.log(error);
    }
  };

  // button for input
  const Input = styled("input")({
    display: "none",
  });

  const router = useRouter();

  // Fetching the database for business data
  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch(`/api/dashboard/manage_employees/${id}`);
        const empData = await res.json();
        const data = empData.empList.map((row) => ({
          ...row,
          id: row._id.toString(),
        }));
        setEmpData(data);

        // get CSV data of employees
        let employeesData = [];
        for (const item of empData.busList) {
          let object = {
            biz_ui: item.biz_ui,
            business_ui: item.biz_ui,
            employees_ui: item.employees_ui,
            name: item.name,
            street: item.street,
            city: item.city,
            province: item.province,
            postal_code: item.postal_code,
            email: item.email,
            status: item.status,
          };
          employeesData.push(object);
        }
        setEmployees(employeesData);
      } catch (error) {
        alert(error);
      }
    };
    fetchData();
  }, []);

  const columns = [
    {field: "biz_ui", headerName: "BIZ Identifier"},
    {field: "business_ui", headerName: "BUS Identifier"},
    {field: "employee_ui", headerName: "Employee Identifier"},
    { field: "name", headerName: "Name", flex: 1 },
    { field: "street", headerName: "Street", flex: 1.5 },
    { field: "city", headerName: "City", flex: 1.5 },
    { field: "province", headerName: "Province", flex: 1.5 },
    { field: "postal_code", headerName: "Postal Code", flex: 0.5 },
    { field: "email", headerName: "Email", flex: 1 },
    {
      field: "status",
      headerName: "Status",
      flex: 0.5,
      renderCell: (params) => (
        <ControlledSwitches
          status={params.row.status}
          changeStatus={async (newStatus) => {
            try {
              // update status in the database
              const response = await fetch(
                `/api/dashboard/manage_business/switch/${params.row.id}`,
                {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json",
                  },
                  body: JSON.stringify({
                    id: params.row.id,
                    status: newStatus,
                  }),
                }
              );

              if (!response.ok)
                throw new Error(`HTTP error! status: ${response.status}`);
              // update status in local state
              setEmpData(
                empData.map((biz) =>
                  biz.id === params.row.id ? { ...biz, status: newStatus } : biz
                )
              );
            } catch (error) {
              console.error("Failed to update status:", error);
            }
          }}
        />
      ),
    },
  ];

  const createNewEmp = () => {
    router.push(`/dashboard/manage_employees/postEmp`);
  };

  const editEmp = () => {
    if (selectedEmp.length === 1) {
      router.push(`/dashboard/manage_employees/editEmp/${selectedEmp[0]}`);
    } else {
      alert("Please select a single row to edit");
    }
  };

  const deleteEmp = () => {
    if (selectedEmp.length === 1) {
      setEmpToDelete(selectedEmp[0]);
      setOpenDeleteModal(true);
    } else {
      alert("Please select a single row to delete");
    }
  };

  const handleDelete = async () => {
    try {
      const res = await fetch(`/api/dashboard/manage_employees/crud/${empToDelete}`, {
        method: "DELETE",
      });

      if (!res.ok) throw res;
      setEmpData(empData.filter((em) => em.id !== empToDelete));
      setSelectedEmp([]);
      setEmpToDelete(null);
      setOpenDeleteModal(false);
    } catch (error) {
      console.log("Failed to delete the employee:", error);
    }
  };

  return (
    <ClientOnly>
    <div style={{ height: 600, width: "100%" }}>
      <ResponsiveNav />
      <DeleteModal
        open={openDeleteModal}
        handleClose={() => setOpenDeleteModal(false)}
        handleDelete={handleDelete}
      />
      <CustomResponsiveFontSizes>Managing employees</CustomResponsiveFontSizes>
      <Grid sx={{ m: 1, p: 1 }}>
        <DashboardDrawer />
        <Button
          variant="contained"
          color="success"
          onClick={createNewEmp}
          sx={{ m: 1, p: 2 }}
        >
          New Employee
        </Button>
        <Button variant="contained" onClick={editEmp} sx={{ m: 1, p: 2 }}>
          Edit Selected Employee
        </Button>
        <Button
          variant="outlined"
          color="error"
          startIcon={<DeleteIcon />}
          onClick={deleteEmp}
          sx={{ m: 1, p: 2 }}
        >
          Delete Selected Employee
        </Button>
        <CSVLink
          data={employees}
          headers={headers}
          filename="Employees.csv"
          style={{ textDecoration: "none" }}
        >
          <Button variant="contained" color="success" sx={{ m: 1, p: 2 }}>
            Generate Report
          </Button>
        </CSVLink>
        <Button variant="contained" sx={{ m: 1, p: 1 }}>
          <label htmlFor="contained-button-file">
            <Input
              accept=".csv"
              id="contained-button-file"
              type="file"
              onChange={UploadFile}
            />
            <Button variant="contained" component="span">
              Upload CSV
            </Button>
          </label>
        </Button>
      </Grid>
      <Grid>
        <DataGrid
          rows={empData}
          columns={columns}
          onRowSelectionModelChange={(newSelection) => {
            setSelectedEmp(newSelection);
          }}
          pageSize={5}
          rowsPerPageOptions={[5]}
          checkboxSelection
          getRowId={(row) => row._id}
          component={Paper}
          style={{
            margin: "0 auto",
            backgroundColor: "#e8e8e6",
            borderRadius: "10px",
          }}
          disableRowSelectionOnClick
        />
        
      </Grid>
    </div>
    </ClientOnly>
  );
};

export default Employees;
