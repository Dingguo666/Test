"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Button, TextField, Container, FormControl, InputLabel, Select, MenuItem } from "@mui/material";
import ResponsiveHeader from "@/components/ResponsiveHeader";
import SendIcon from "@mui/icons-material/Send";
import { styled } from "@mui/system";
import ClientOnly from "@/components/clientOnly";

const Background = styled("div")({
  backgroundColor: "#e8e8e6",
  backgroundRepeat: "no-repeat",
  backgroundSize: "cover",
  height: "100vh",
});

const PostBus = () => {
  //biz unique identifier
  const [bizUiOptions, setBizUiOptions] = useState([]);  // Array to store biz_ui options
  const [selectedBizUi, setSelectedBizUi] = useState(""); // Selected biz_ui value

  const [busUi, setBusUi] = useState("");
  const [busName, setBusName] = useState("");
  const [street, setStreet] = useState("");
  const [city, setCity] = useState("");
  const [province, setProvince] = useState("");
  const [postalCode, setPostalCode] = useState("");
  const [contactPerson, setContactPerson] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [email, setEmail] = useState("");
  const router = useRouter();

  useEffect(() => {
    // Fetch biz_ui data when component mounts
    const fetchBizUiData = async () => {
      try {
        const res = await fetch("/api/dashboard/manage_biz/getBizUi");
        const data = await res.json();
        setBizUiOptions(data.bizUiList);
      } catch (error) {
        console.error("Error:", error);
      }
    };
    fetchBizUiData();
  }, []);

  const handleSubmit = async (event) => {
    event.preventDefault();

    const busData = {
      biz_ui: selectedBizUi,
      business_ui: busUi,
      business_name: busName,
      street,
      city,
      province,
      postal_code: postalCode,
      contact_person: contactPerson,
      phone_number: phoneNumber,
      email,
      status: true,
    };

    try {
      const res = await fetch("/api/dashboard/manage_business/crud/post", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(busData),
      });
      const data = await res.json();

      if (res.status !== 200) {
        alert(data.message);
      }

      // Use router.push to navigate to the getBus page
      if (res.status === 200) {
        alert("Success!");
        router.push("/dashboard/manage_business");
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  return (
    <ClientOnly>
    <Background>
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          minHeight: "50vh",
        }}
      >
        <div>
          <div style={{ margin: "15px" }}>
            <ResponsiveHeader>
            Register a Business
            </ResponsiveHeader>
          </div>
          <Container>
            <form onSubmit={handleSubmit}>
            <FormControl style={{ width: "400px" }}>
                <InputLabel id="biz-ui-label">Biz UI</InputLabel>
                <Select
                  labelId="biz-ui-label"
                  id="biz-ui-label"
                  value={selectedBizUi}
                  onChange={(e) => setSelectedBizUi(e.target.value)}
                  sx={{ my: "12px" }}
                >
                  {bizUiOptions.map((option) => (
                    <MenuItem key={option} value={option}>{option}</MenuItem>
                  ))}
                </Select>
              </FormControl>
              <br />
            <TextField
                label="Business Unique Identifier"
                value={busUi}
                onChange={(e) => setBusUi(e.target.value)}
                style={{ width: "400px" }}
                sx={{ my: "12px" }}
              />
              <br />
              <TextField
                label="Business Name"
                value={busName}
                onChange={(e) => setBusName(e.target.value)}
                style={{ width: "400px" }}
                sx={{ my: "12px" }}
              />
              <br />
              <TextField
                label="Street"
                value={street}
                onChange={(e) => setStreet(e.target.value)}
                style={{ width: "400px" }}
                sx={{ my: "12px" }}
              />
              <br />
              <TextField
                label="City"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                style={{ width: "400px" }}
                sx={{ my: "12px" }}
              />
              <br />
              <TextField
                label="Province"
                value={province}
                onChange={(e) => setProvince(e.target.value)}
                style={{ width: "400px" }}
                sx={{ my: "12px" }}
              />
              <br />
              <TextField
                  label="Postal Code"
                  value={postalCode}
                  onChange={(e) => setPostalCode(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                />
                <br />
              <TextField
                  label="Contact Person"
                  value={contactPerson}
                  onChange={(e) => setContactPerson(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                />
                <br />
              <TextField
                label="Phone Number"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                style={{ width: "400px" }}
                sx={{ my: "12px" }}
              />
              <br />
              <TextField
                label="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                style={{ width: "400px" }}
                sx={{ my: "12px" }}
              />
              <br />
              <Button
                type="submit"
                variant="contained"
                endIcon={<SendIcon />}
                sx={{
                  m: 1,
                  p: 2,
                  display: "flex",
                }}
              >
                Register
              </Button>
            </form>
          </Container>
        </div>
      </div>
    </Background>
    </ClientOnly>
  );
};

export default PostBus;
