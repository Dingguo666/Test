"use client";

import { useState, useEffect } from "react";
import { useRouter, useParams } from "next/navigation";
import { Button, TextField, Container, FormControl, InputLabel, Select, MenuItem } from "@mui/material";
import ResponsiveHeader from "@/components/ResponsiveHeader";
import SendIcon from "@mui/icons-material/Send";
import { styled } from "@mui/system";

const Background = styled("div")({
  backgroundColor: "#e8e8e6",
  backgroundRepeat: "no-repeat",
  backgroundSize: "cover",
  height: "100vh",
});

const EditBus = () => {
  const router = useRouter();
  const { id } = useParams("id");

//biz unique identifier
  const [bizUiOptions, setBizUiOptions] = useState([]);  // Array to store biz_ui options
  const [selectedBizUi, setSelectedBizUi] = useState(""); // Selected biz_ui value


  const [busUi, setBusUi] = useState("");
  const [busName, setBusName] = useState("");
  const [street, setStreet] = useState("");
  const [city, setCity] = useState("");
  const [province, setProvince] = useState("");
  const [postalCode, setPostalCode] = useState("");
  const [contactPerson, setContactPerson] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState("");

  useEffect(() => {
    const fetchBusBiz = async () => {
      try {
        // Get initial data for this business
        const response = await fetch(
          `/api/dashboard/manage_business/crud/${id}`
        );
        const bus = await response.json();

        // Get data for biz_ui options
        const res = await fetch("/api/dashboard/manage_biz/getBizUi");
        const biz = await res.json();
        setBizUiOptions(biz.bizUiList);

        setBusUi(bus.business_ui);
        setBusName(bus.business_name);
        setStreet(bus.street);
        setCity(bus.city);
        setProvince(bus.province);
        setPostalCode(bus.postal_code);
        setContactPerson(bus.contact_person);
        setPhoneNumber(bus.phone_number);
        setEmail(bus.email);
        setStatus(bus.status);

        // Set selectedBizUi to the current biz_ui of the business
        setSelectedBizUi(bus.biz_ui);
      } catch (error) {
        console.error("Error:", error);
      }
    };

    if (id) {
      fetchBusBiz();
    }
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch(`/api/dashboard/manage_business/crud/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          biz_ui: selectedBizUi,
          business_ui: busUi,
          business_name: busName,
          street,
          city,
          province,
          postal_code: postalCode,
          contact_person: contactPerson,
          phone_number: phoneNumber,
          email,
          status,
        }),
      });

      if (res.ok) {
        alert("Business updated successfully");
        router.push("/dashboard/manage_business");
      } else {
        const errorData = await res.json();
        alert(errorData.message);
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  return (
    <body style={{ margin: "0", padding: "0" }}>
      <Background>
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            minHeight: "50vh",
          }}
        >
          <div>
            <div style={{ margin: "15px" }}>
              <ResponsiveHeader>Edit Business</ResponsiveHeader>
            </div>
            <Container>
              <form onSubmit={handleSubmit}>
              <FormControl style={{ width: "400px" }}>
                <InputLabel id="biz-ui-label">Biz UI</InputLabel>
                <Select
                  labelId="biz-ui-label"
                  id="biz-ui-label"
                  value={selectedBizUi}
                  onChange={(e) => setSelectedBizUi(e.target.value)}
                  sx={{ my: "12px" }}
                >
                  {bizUiOptions.map((option) => (
                    <MenuItem key={option} value={option}>{option}</MenuItem>
                  ))}
                </Select>
              </FormControl>
                <TextField
                  label="Business Unique Identifier"
                  value={busUi}
                  onChange={(e) => setBusUi(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                />
                <br />
                <TextField
                  label="Business Name"
                  value={busName}
                  onChange={(e) => setBusName(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                />
                <br />
                <TextField
                  label="Street"
                  value={street}
                  onChange={(e) => setStreet(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                />
                <br />
                <TextField
                  label="City"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                />
                <br />
                <TextField
                  label="Province"
                  value={province}
                  onChange={(e) => setProvince(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                />
                <br />
                <TextField
                  label="Postal Code"
                  value={postalCode}
                  onChange={(e) => setPostalCode(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                />
                <br />
                <TextField
                  label="Contact Person"
                  value={contactPerson}
                  onChange={(e) => setContactPerson(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                />
                <br />
                <TextField
                  label="Phone Number"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                />
                <br />
                <TextField
                  label="Email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  style={{ width: "400px" }}
                  sx={{ my: "12px" }}
                />
                <br />
                <Button
                  type="submit"
                  variant="contained"
                  endIcon={<SendIcon />}
                  sx={{
                    m: 1,
                    p: 2,
                    display: "flex",
                  }}
                >
                  Update
                </Button>
              </form>
            </Container>
          </div>
        </div>
      </Background>
    </body>
  );
};

export default EditBus;
