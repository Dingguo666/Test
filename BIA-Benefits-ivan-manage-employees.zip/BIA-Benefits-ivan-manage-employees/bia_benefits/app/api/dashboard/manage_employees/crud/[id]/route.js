import BUS from "@/models/businessEmployeesSchema";
import connectDB from "@/utils/connectDB";

// GET function
export const GET = async (request, {params}) => {

    try {
      await connectDB();
      const bus = await BUS.findById(params.id);

    // Extract only the 'employees' array from the business
    const employees = bus.employees;

      if (!bus) return new Response("Business Not Found", { status: 404 });

      // Extract only the 'biz_ui', 'business_ui', and 'employees' from the business
     const data = {
       biz_ui: bus.biz_ui,
       business_ui: bus.business_ui,
       employees: bus.employees
     };

     // Return the extracted data
     return new Response(JSON.stringify(data), { status: 200 })

    } catch (error) {
      console.log(error);
      return new Response.json({ message: "Server error", error: error.message });
    }
  }


  // PUT function
  export const PUT = async (request, {params}) => {

    const { biz_ui, business_ui, business_name, street, city, province, postal_code, contact_person, phone_number, email, status } = await request.json();

    try {
      await connectDB();

      //Find the existing Business by ID
      const updatedBus = await BUS.findByIdAndUpdate(params.id);

      if(!updatedBus) {
        return new Response("Business not found", {status: 404});
      }

      //Update the Business with new data
      updatedBus.biz_ui = biz_ui;
      updatedBus.business_ui = business_ui;
      updatedBus.business_name = business_name;
      updatedBus.street = street;
      updatedBus.city = city;
      updatedBus.province = province;
      updatedBus.postal_code = postal_code;
      updatedBus.contact_person = contact_person;
      updatedBus.phone_number = phone_number;
      updatedBus.email = email;
      updatedBus.status = status;

      updatedBus.save();

      return new Response("Successfully updated the Business", { status: 200 });
    } catch (error) {
      console.log(error);
      return new Response("Error Updating Business", { status: 500 });
    }
  }


  // POST function
  export const POST = async (request) => {

    const { biz_ui, business_ui, business_name, street, city, province, postal_code, contact_person, phone_number, email, status } =
      await request.json();

    try {
      await connectDB();
      const newBus = new BUS({ biz_ui, business_ui, business_name, street, city, province, postal_code, contact_person, phone_number,email, status});
      await newBus.save();
      return new Response(JSON.stringify(newBus), { status: 200 })
  } catch (error) {

       // Mongoose will throw an error if validation fails
      // We'll catch the error and return it in the response
      return new Response(
          JSON.stringify({ message: error.message }),
          { status: 400 }
        );
  }
  }


  // DELETE function
  export const DELETE = async (request, {params}) => {
    try {
      await connectDB();

      // Find the business by ID and remove it
      await BUS.findByIdAndDelete(params.id);
      return new Response("Business deleted successfully", {status: 200});

    } catch (error) {
      console.log(error);
      return new Response("Error deleting BIA", { status: 500 });
    }
  }
