import CorporatePartners from "@/models/corporatePartnerSchema";
import connectDB from "@/utils/connectDB";

export const POST = async (req, {params}) => {
  const { status } = await req.json();
    try {
      await connectDB();

      //Find the existing Corporate Partner by ID
      const updatedStatus = await CorporatePartners.findByIdAndUpdate(params.id, {status: status}, {new: true});
      
      if(!updatedStatus) {
        return new Response("Corporate Partner is not found", {status: 404});
      }

      //Update the Corporate Partner with new status
      updatedStatus.status = status;

      return new Response("Successfully updated the Corporate status", { status: 200 });
    } catch (error) {
      console.log(error);
      return new Response("Error Updating Corporate Partner", { status: 500 });
    }
  }