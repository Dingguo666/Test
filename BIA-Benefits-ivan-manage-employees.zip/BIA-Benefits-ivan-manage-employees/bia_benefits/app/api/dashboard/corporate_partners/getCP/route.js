
import CorporatePartners from "@/models/corporatePartnerSchema";
import connectDB from "@/utils/connectDB";
import { NextResponse } from "next/server";

export async function GET(){
    await connectDB();

    const corpPartnerList = await CorporatePartners.find();

    return NextResponse.json({corpPartnerList});

}
