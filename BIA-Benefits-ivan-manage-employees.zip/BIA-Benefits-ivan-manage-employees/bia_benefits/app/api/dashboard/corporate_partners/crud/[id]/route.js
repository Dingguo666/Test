import CorporatePartners from "@/models/corporatePartnerSchema";
import connectDB from "@/utils/connectDB";


export const GET = async (request, {params}) => {
   
    try {
      await connectDB();
      const corpP = await CorporatePartners.findById(params.id);

      if (!corpP) return new Response("Corporate Partner is Not Found", { status: 404 });

      return new Response(JSON.stringify(corpP), { status: 200 })

    } catch (error) {
      console.log(error);
      return new Response.json({ message: "Server error", error: error.message });
    }
  }
  
  export const PUT = async (request, {params}) => {

    const { partner_name, street, city, province, postal_code, contact_person, phone_number,  email, status } = await request.json();
  
    try {
      await connectDB();
      
      //Find the existing Corporate Partner by ID
      const updatedCorpPartner = await CorporatePartners.findByIdAndUpdate(params.id);
      
      if(!updatedCorpPartner) {
        return new Response("Corporate Partner is not found", {status: 404});
      }

      //Update the Corporate Partner with new data
      updatedCorpPartner.partner_name = partner_name;
      updatedCorpPartner.street = street;
      updatedCorpPartner.city = city;
      updatedCorpPartner.province = province;
      updatedCorpPartner.postal_code = postal_code;
      updatedCorpPartner.contact_person = contact_person;
      updatedCorpPartner.phone_number = phone_number;
      updatedCorpPartner.email = email;
      updatedCorpPartner.status = status;

      updatedCorpPartner.save();

      return new Response("Successfully updated the Corporate Partner", { status: 200 });
    } catch (error) {
      console.log(error);
      return new Response("Error Updating Corporate Partner", { status: 500 });
    }
  }

  export const POST = async (request) => {
    
    const { partner_name, street, city, province, postal_code, contact_person, phone_number, email, status } =
      await request.json();
  
    try {
      await connectDB();
      const newCorpPartner = new CorporatePartners({ partner_name, street, city, province, postal_code, contact_person, phone_number, email, status});
      await newCorpPartner.save();
      return new Response(JSON.stringify(newCorpPartner), { status: 200 })
  } catch (error) {
  
       // Mongoose will throw an error if validation fails
      // We'll catch the error and return it in the response
      return new Response(
          JSON.stringify({ message: error.message }),
          { status: 400 }
        );
  }
  }
  
  export const DELETE = async (request, {params}) => {
    try {
      await connectDB();
      
      // Find the Corporate Partner by ID and remove it
      await CorporatePartners.findByIdAndDelete(params.id);
      return new Response("Corporate Partner deleted successfully", {status: 200});

    } catch (error) {
      console.log(error);
      return new Response("Error deleting Corporate Partner", { status: 500 });
    }
  }
  