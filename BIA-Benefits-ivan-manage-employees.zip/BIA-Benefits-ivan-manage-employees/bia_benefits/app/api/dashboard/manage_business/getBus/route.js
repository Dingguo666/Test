
import BUS from "@/models/businessEmployeesSchema";
import connectDB from "@/utils/connectDB";
import { NextResponse } from "next/server";

export async function GET(){
    await connectDB();

    const busList = await BUS.find();

    return NextResponse.json({busList});

}
