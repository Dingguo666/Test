import BUS from "@/models/businessEmployeesSchema";
import connectDB from "@/utils/connectDB";

export const POST = async (req, {params}) => {
  const { status } = await req.json();
    try {
      await connectDB();

      //Find the existing business by ID
      const updatedStatus = await BUS.findByIdAndUpdate(params.id, {status: status}, {new: true});
      
      if(!updatedStatus) {
        return new Response("Business not found", {status: 404});
      }

      //Update the business with new status
      updatedStatus.status = status;

      return new Response("Successfully updated the business status", { status: 200 });
    } catch (error) {
      console.log(error);
      return new Response("Error Updating business", { status: 500 });
    }
  }