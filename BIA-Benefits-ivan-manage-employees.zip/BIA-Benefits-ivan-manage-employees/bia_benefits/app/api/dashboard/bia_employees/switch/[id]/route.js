import BiaEmp from "@/models/biaEmployeeSchema";
import connectDB from "@/utils/connectDB";

export const POST = async (req, {params}) => {
  const { status } = await req.json();
    try {
      await connectDB();

      //Find the existing Bia Benefits Employee by ID
      const updatedStatus = await BiaEmp.findByIdAndUpdate(params.id, {status: status}, {new: true});
      
      if(!updatedStatus) {
        return new Response("Bia Benefits Employee is not found", {status: 404});
      }

      //Update the Bia Benefits Employee with new status
      updatedStatus.status = status;

      return new Response("Successfully updated the Bia Benefits Employee status", { status: 200 });
    } catch (error) {
      console.log(error);
      return new Response("Error Updating Bia Benefits Employee", { status: 500 });
    }
  }