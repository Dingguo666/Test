import BiaEmp from "@/models/biaEmployeeSchema";
import connectDB from "@/utils/connectDB";

// GET function
export const GET = async (request, { params }) => {
  try {
    await connectDB();
    const biaEmp = await BiaEmp.findById(params.id);

    if (!biaEmp)
      return new Response("This Employee is Not Found", { status: 404 });

    return new Response(JSON.stringify(biaEmp), { status: 200 });
  } catch (error) {
    console.log(error);
    return new Response.json({ message: "Server error", error: error.message });
  }
};

// UPLOAD function
export const PUT = async (request, { params }) => {
  const { employee_name, employee_email, user_type, status } =
    await request.json();

  try {
    await connectDB();

    //Find the existing employee by ID
    const updatedbiaEmp = await BiaEmp.findByIdAndUpdate(params.id);

    if (!updatedbiaEmp) {
      return new Response("This employee is not found", { status: 404 });
    }

    //Update the employee with new data
    updatedbiaEmp.employee_name = employee_name;
    updatedbiaEmp.employee_email = employee_email;
    updatedbiaEmp.user_type = user_type;
    updatedbiaEmp.status = status;

    updatedbiaEmp.save();

    return new Response("Successfully updated the employee", { status: 200 });
  } catch (error) {
    console.log(error);
    return new Response("Error Updating employee", { status: 500 });
  }
};


// POST function
export const POST = async (request) => {
  const { employee_name, employee_email, user_type, status } =
    await request.json();

  try {
    await connectDB();
    const newbiaEmp = new BiaEmp({
      employee_name,
      employee_email,
      user_type,
      status,
    });
    await newbiaEmp.save();
    return new Response(JSON.stringify(newbiaEmp), { status: 200 });
  } catch (error) {
    // Mongoose will throw an error if validation fails
    // Catch the error and return it in the response
    return new Response(JSON.stringify({ message: error.message }), {
      status: 400,
    });
  }
};


// DELETE function
export const DELETE = async (request, { params }) => {
  try {
    await connectDB();

    // Find the employee by ID and remove it
    await BiaEmp.findByIdAndDelete(params.id);
    return new Response("Employee deleted successfully", { status: 200 });
  } catch (error) {
    console.log(error);
    return new Response("Error deleting employee", { status: 500 });
  }
};
