
import BiaEmp from "@/models/biaEmployeeSchema";
import connectDB from "@/utils/connectDB";
import { NextResponse } from "next/server";

export async function GET(){
    await connectDB();

    const biaEmployeeList = await BiaEmp.find();

    return NextResponse.json({biaEmployeeList});

}
