
import BIZ from "@/models/bizSchema";
import connectDB from "@/utils/connectDB";
import { NextResponse } from "next/server";

export async function GET(){
    await connectDB();

    // Specify 'biz_ui' field to include only unique biz_ui
    const bizUiList = await BIZ.distinct('biz_ui');

    return NextResponse.json({bizUiList});
}
