import BIZ from "@/models/bizSchema";
import connectDB from "@/utils/connectDB";

export const POST = async (req, {params}) => {
  const { status } = await req.json();
    try {
      await connectDB();

      //Find the existing BIZ by ID
      const updatedStatus = await BIZ.findByIdAndUpdate(params.id, {status: status}, {new: true});
      
      if(!updatedStatus) {
        return new Response("BIZ not found", {status: 404});
      }

      //Update the BIZ with new status
      updatedStatus.status = status;

      return new Response("Successfully updated the BIZ status", { status: 200 });
    } catch (error) {
      console.log(error);
      return new Response("Error Updating BIZ", { status: 500 });
    }
  }