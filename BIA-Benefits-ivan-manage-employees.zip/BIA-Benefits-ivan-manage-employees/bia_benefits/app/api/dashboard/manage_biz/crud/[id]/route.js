import BIZ from "@/models/bizSchema";
import connectDB from "@/utils/connectDB";

// GET function
export const GET = async (request, {params}) => {
   
    try {
      await connectDB();
      const biz = await BIZ.findById(params.id);

      if (!biz) return new Response("BIA Not Found", { status: 404 });

      return new Response(JSON.stringify(biz), { status: 200 })

    } catch (error) {
      console.log(error);
      return new Response.json({ message: "Server error", error: error.message });
    }
  }
  

  // PUT function
  export const PUT = async (request, {params}) => {

    const { biz_name, street, city, province, postal_code, contact_person, phone_number, email, status } = await request.json();
  
    try {
      await connectDB();
      
      //Find the existing BIA by ID
      const updatedBiz = await BIZ.findByIdAndUpdate(params.id);
      
      if(!updatedBiz) {
        return new Response("BIA not found", {status: 404});
      }

      //Update the BIA with new data
      updatedBiz.biz_name = biz_name;
      updatedBiz.street = street;
      updatedBiz.city = city;
      updatedBiz.province = province;
      updatedBiz.postal_code = postal_code;
      updatedBiz.contact_person = contact_person;
      updatedBiz.phone_number = phone_number;
      updatedBiz.email = email;
      updatedBiz.status = status;

      updatedBiz.save();

      return new Response("Successfully updated the BIA", { status: 200 });
    } catch (error) {
      console.log(error);
      return new Response("Error Updating BIA", { status: 500 });
    }
  }


  // POST function
  export const POST = async (request) => {
    
    const { biz_name, street, city, province, postal_code, contact_person, phone_number, email, status } =
      await request.json();
  
    try {
      await connectDB();
      const newBiz = new BIZ({ biz_name, street, city, province, postal_code, contact_person, phone_number,email, status});
      await newBiz.save();
      return new Response(JSON.stringify(newBiz), { status: 200 })
  } catch (error) {
  
       // Mongoose will throw an error if validation fails
      // We'll catch the error and return it in the response
      return new Response(
          JSON.stringify({ message: error.message }),
          { status: 400 }
        );
  }
  }
  

  // DELETE function
  export const DELETE = async (request, {params}) => {
    try {
      await connectDB();
      
      // Find the BIZ by ID and remove it
      await BIZ.findByIdAndDelete(params.id);
      return new Response("BIA deleted successfully", {status: 200});

    } catch (error) {
      console.log(error);
      return new Response("Error deleting BIA", { status: 500 });
    }
  }
  