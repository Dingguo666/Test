
import BIZ from "@/models/bizSchema";
import connectDB from "@/utils/connectDB";
import { NextResponse } from "next/server";

export async function GET(){
    await connectDB();

    const bizList = await BIZ.find();

    return NextResponse.json({bizList});

}
