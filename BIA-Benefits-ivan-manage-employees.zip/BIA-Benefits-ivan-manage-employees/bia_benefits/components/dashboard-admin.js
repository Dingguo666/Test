// material ua - drawer

import * as React from "react";
import Box from "@mui/material/Box";
import Drawer from "@mui/material/Drawer";
import Button from "@mui/material/Button";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import WorkIcon from "@mui/icons-material/Work";
import Link from "next/link";

export default function DashboardDrawer() {
  const [state, setState] = React.useState({
    Dashboard: false,
  });

  // Dashboard links
  const links = [
    "/dashboard/bia_employees",
    "/dashboard/corporate_partners",
    "/dashboard/manage_biz",
    "/dashboard/manage_business",
  ];

  const toggleDrawer = (anchor, open) => (event) => {
    if (
      event.type === "keydown" &&
      (event.key === "Tab" || event.key === "Shift")
    ) {
      return;
    }

    setState({ ...state, [anchor]: open });
  };

  const list = (anchor) => (
    <Box
      sx={{ width: anchor === "top" || anchor === "bottom" ? "auto" : 250 }}
      role="presentation"
      onClick={toggleDrawer(anchor, false)}
      onKeyDown={toggleDrawer(anchor, false)}
    >
      <List>
        {[
          "Manage BIA employees",
          "Manage Corporate Partners",
          "Manage BIAs",
          "Manage Business",
        ].map((text, index) => (
          <ListItem key={text} disablePadding>
            <ListItemButton component={Link} to={links[index]}>
              <ListItemIcon>
                <WorkIcon />
              </ListItemIcon>
              <ListItemText primary={text} />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </Box>
  );

  return (
    <>
      {["left"].map((anchor) => (
        <React.Fragment key={anchor}>
          
          {/* Changing button text from 'left' to 'Dashboard' */}
          <Button
            variant="contained"
            sx={{ m: 1, p: 2 }}
            onClick={toggleDrawer(anchor, true)}
          >
            {anchor === "left" ? "Dashboard" : anchor}
          </Button>{" "}
          <Drawer
            anchor={anchor}
            open={state[anchor]}
            onClose={toggleDrawer(anchor, false)}
          >
            {list(anchor)}
          </Drawer>
        </React.Fragment>
      ))}
    </>
  );
}
