import * as React from "react";
import Switch from "@mui/material/Switch";

export default function ControlledSwitches({ status, changeStatus }) {
  const handleChange = (event) => {
    changeStatus(event.target.checked);
  };

  return (
    <Switch
      checked={status}
      onChange={handleChange}
      inputProps={{ "aria-label": "controlled" }}
    />
  );
}
