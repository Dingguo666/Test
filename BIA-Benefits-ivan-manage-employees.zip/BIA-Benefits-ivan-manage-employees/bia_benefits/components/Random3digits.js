import React, { useState, useEffect } from 'react';

const RandomNumberGenerator = () => {
  const [randomNumber, setRandomNumber] = useState(null);

  useEffect(() => {
    generateRandomNumber();
  }, []);

  const generateRandomNumber = () => {
    const number = Math.floor(Math.random() * 900) + 100;
    setRandomNumber(number);
  }

//   return (
//     <div>
//       <h1>Random Number: {randomNumber}</h1>
//       <button onClick={generateRandomNumber}>Generate New Number</button>
//     </div>
//   );
}

export default RandomNumberGenerator;
