import React, { useEffect, useState } from 'react';

const ClientOnly = (props) => {
  const [hasMounted, setHasMounted] = useState(false);

  useEffect(() => {
    setHasMounted(true);
  }, []);

  if (!hasMounted) {
    return null;
  }

  return React.createElement('div', props, props.children);
};
export default ClientOnly;
